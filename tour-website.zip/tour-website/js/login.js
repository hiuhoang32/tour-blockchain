Vue.createApp({
    data(){
        return{
            view: "signin"
        }
    }

}).mount('#login-form');